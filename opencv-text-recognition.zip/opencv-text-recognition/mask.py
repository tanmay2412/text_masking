import cv2

src1 = cv2.imread(r"C:\Users\Tanmay.Tondase\Tanmay_dev\opencv\demo\opencv-text-recognition\data2.jpeg")
src2 = cv2.imread(r"C:\Users\Tanmay.Tondase\Tanmay_dev\opencv\demo\opencv-text-recognition\ref.jpg")

src2 = cv2.resize(src2, src1.shape[1::-1])


dst = cv2.addWeighted(src1, 0.5, src2, 0.5, 0)

#cv2.imwrite('opencv_add_weighted.jpg', dst)

dst = cv2.addWeighted(src1, 0.5, src2, 0.2, 128)

#cv2.imwrite('opencv_add_weighted_gamma.jpg', dst)


dst = cv2.bitwise_and(src1, src2)

cv2.imwrite('opencv_bitwise_and_result.jpg', dst)

