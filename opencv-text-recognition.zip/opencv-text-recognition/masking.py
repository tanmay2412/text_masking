import cv2
import numpy as np

src = cv2.imread(r'C:\Users\Tanmay.Tondase\Tanmay_dev\opencv\demo\opencv-text-recognition\images\data2.jpeg')

mask = np.zeros_like(src)

print(mask.shape)
# (225, 400, 3)

print(mask.dtype)
# uint8

cv2.rectangle(mask, (210, 61), (890, 107), (255, 255, 255), thickness=-1)
cv2.rectangle(mask, (130, 126), (890, 171), (255, 255, 255), thickness=-1)
cv2.rectangle(mask, (149, 178), (890, 224), (255, 255, 255), thickness=-1)
cv2.rectangle(mask, (206, 241), (606, 286), (255, 255, 255), thickness=-1)
cv2.rectangle(mask, (681,241), (890, 285), (255, 255, 255), thickness=-1)
cv2.rectangle(mask, (232, 298), (890, 353), (255, 255, 255), thickness=-1)
#cv2.circle(mask, (200, 100), 50, (255, 255, 255), thickness=-1)
#cv2.fillConvexPoly(mask, np.array([[330, 50], [300, 200], [360, 150]]), (255, 255, 255))

#cv2.imwrite('opencv_draw_mask1.jpg', mask)

#mask_blur = cv2.GaussianBlur(mask, (51, 51), 0)

cv2.imwrite('opencv_draw_mask_blur.jpg', mask)

dst = src * (mask / 255)

cv2.imwrite('opencv_draw_mask_blur_result1.jpg', dst)

cv2.imshow("abc", dst) 
cv2.imshow("mask",mask)
cv2.waitKey(0)


gray=cv2.cvtColor(dst,cv2.COLOR_BGR2GRAY)
contours, hierarchy = cv2.findContours(gray,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)[-2:]
idx =0 
for cnt in contours:
    idx += 1
    x,y,w,h = cv2.boundingRect(cnt)
    roi=im[y:y+h,x:x+w]
    cv2.imwrite(str(idx) + '.jpg', roi)
    #cv2.rectangle(im,(x,y),(x+w,y+h),(200,0,0),2)

cv2.waitKey(0)    